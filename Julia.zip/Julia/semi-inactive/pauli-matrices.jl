global const σx = [0 1; 1 0]
global const σy = [0 -im; im 0]
global const σz = [1 0; 0 -1]
global const I2 = [1 0; 0 1]
