function kron(array1::Array, array2::Array)		#2d arrays only, overload for other cases
	try
		(r1,c1) = size(array1)
		(r2,c2) = size(array2)
	catch e
		if isa(e,BoundsError)
			return kron(array1, array2)
		else 
			print(e) 
			return nothing 
		end
	end
	(r1,c1) = size(array1)
	(r2,c2) = size(array2)
	m = 0
	n = 0
	
	result = zeros(Complex{Float64},r1*r2,c1*c2)
	
	for j = 1:c1
		for i = 1:r1
			n = n%(c1*c2)+1
			for l = 1:c2
				n = (j-1)*c2+l
				for k = 1:r2
					m = (i-1)*r2+k		#rearrange in loop for optimization
					result[m,n] = array1[i,j]*array2[k,l]
				end
			end
		end
	end
	return result
end

function kron(vec1::Vector, vec2::Vector)
	d1 = size(vec1)
	d2 = size(vec2)
	d = d1[1]*d2[1]
	
	result = zeros(Complex{Float64},d)
	
	for i = 1:d1[1]
		for j = 1:d2[1]
			result[(i-1)*d2[1]+j] = vec1[i]*vec2[j]	#could be optimized slightly
		end
	end
	return result
end

#try generalising these pleaese
function kron(matrix::Matrix, value::Number)
	return value .* matrix
end

function kron(value::Number, matrix)
	return value .* matrix
end

function kron(value1::Number, value2::Number)
	return value1*value2
end

#display(a) to show matrixx
