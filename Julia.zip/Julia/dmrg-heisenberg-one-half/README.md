# dmrg-heisenberg-one-half
toy model for practice, using dmrg on a heisenberg one half spin system
