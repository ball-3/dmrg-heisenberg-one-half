#Note : determined errors when x, yn are not all of the same type (row OR column vector), so must ensure same type
#TODO make this work BRUH
using Plots

defaultcolours = [red parse(Colorant, "blue1") green parse(Colorant, "blue1") blue parse(Colorant, "blue1")]

function plotl(title::String, save::Bool,#=colours=defaultcolours,=# y...)

	if (isempty(y)) return end
	
	ys = size(y,1)
	colours = defaultcolours
	colourslength =  max(size(colours)[1],size(colours)[2])
	
	plot(ys)
	plot!(legend=:topright)
	title!(title)
	xlabel!("1/N")
	ylabel!("GSE/N")
	#plot!(xscale=:log10, yscale=:log10, minorgrid=true)
	
	n = size(y[1])[1]
	for i = 1:(ys-1)	
		n = max(size(y[i])[1],size(y[i+1])[1])
	end
	
	x = [1/(2*i) for i in 1:n]
	#display(x)
	#display(y)
	
	for i = 1:ys
	#display(y[i])
		for j = 1:(size(y[i],1))
			scatter!(x, y[i][j], label = "y$i")
		end
		#scatter!(x, y[i], label="y$i", mc=:colours[(i%colourslength)], ms=(ys-i), ma=0.5)
	end

	if save
		png(title)
	end
end

plotl("joebiden>:0",true,[1,2,3,4,5],[1,1,1,1,1,1,1,1,1],[10,20,15,36,11],[2,-5,0],[0],[22])
