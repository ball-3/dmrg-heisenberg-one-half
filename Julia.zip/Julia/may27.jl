using ITensors, ITensorMPS
using Printf
using Random

Random.seed!(6969)

function main(length, jl, jr)
	
	N = length*2
	Jl = jl		#inter dimer interaction
	Jr = jr		#intra dimer interaction
			#we are testing limit Jr >> Jl

	sites = siteinds("S=1/2", N)
	
	os = OpSum()
	for j in 1:(N-3)
		#lower leg inter dimer
		os += Jl, "Sz", j, "Sz", j+2
		os += Jl*0.5, "S+", j, "S-", j+2
		os += Jl*0.5, "S-", j, "S+", j+2

		#upper leg inter dimer 
		os += Jl, "Sz", j+1, "Sz", j+3
		os += Jl*0.5, "S+", j+1, "S-", j+3
		os += Jl*0.5, "S-", j+1, "S+", j+3
	end
	
	for j in 1:2:(N-1)	
		#intra dimer
		os += Jr, "Sz", j, "Sz", j+1
		os += Jr*0.5, "S+", j, "S-", j+1
		os += Jr*0.5, "S-", j, "S+", j+1
	end
	
	H = MPO(os, sites)
	
	psi0 = randomMPS(sites; linkdims=10)
	
	nsweeps = 10
	maxdim = [10,20,100,100,200]
	
	cutoff = [1e-6]
	
	energy, psi = dmrg(H, psi0; nsweeps, maxdim, cutoff)
	
	#@printf("Final energy = %.12f, n = %d, Jl = %f, Jr = %f\n", energy, N, Jl, Jr)
	
	energy
	#display(psi)
end

#main(4,1,1)

