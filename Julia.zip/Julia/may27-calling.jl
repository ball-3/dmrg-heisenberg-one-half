using Printf

include("heisenberg-one-half.jl")
include("may27.jl")
include("may28-plotting.jl")

include("./semi-inactive/Hamiltonians.jl")
include("./semi-inactive/exact-diagonalisation.jl")

function runit(maxLength, jAlters, jrbyjl)	#temporarily f just means times, so Jl is altered by Jl *= fJl
	for j = 0:jAlters
		ratio = j*jrbyjl/jAlters
		norm = sqrt(1 + ratio^2)
		Jl = 1/norm
		Jr = ratio/norm
		
		energyED = zeros(maxLength)
		energyDMRG = zeros(maxLength)
		
		@printf("This time we are with norm %f and j value %d", norm, j)
		
		for i = 1:maxLength
			energyDMRG[i] = main(i,Jl,Jr)
			energyED[i] = gsE(Hamiltonians.ladderOneHalf(i,Jl,Jr))
		end
		
		plotl(energyDMRG,energyED,"edition $j", true)
	end
end

function runit2(maxLength, js)
	for j = 1:size(js)[1]
		Jl = js[j,1]
		Jr = js[j,2]
		
		energyED = zeros(maxLength)
		energyDMRG = zeros(maxLength)
		energyHeis = zeros(maxLength)
		
		@printf("This time we are with norm %f and j value %d\n", Jl/Jr, j)
		
		for i = 1:maxLength
			energyDMRG[i] = main(i,Jl,Jr)
			energyED[i] = gsE(Hamiltonians.ladderOneHalf(i,Jl,Jr))
			energyHeis[i] = main2(2*i)
		end
		
		plotl(energyDMRG,energyED,energyHeis,"alternative $j", true)
	end
end

m = [100 0;10 0;1 0]

runit2(5,m)

#runit(5, 10, 1000)
